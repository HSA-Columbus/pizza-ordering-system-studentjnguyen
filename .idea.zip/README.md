# Pizza Ordering System - Project

## Create a Pizza ordering form for your local favorite pizza restuarunt.

1. You must use the Object Oriented Programming methodology to do this project
2. I strongly suggest you use Flask and HTML to do the UI.
3. The design of the UI is upto your creativity but you can follow the screenshots given if you must choose.
4. Use Python OOP to do the backend.
# 5. See the grading rubric in the Google Classroom for score breakdown and extra credit oppurtunity.

![Image of Yaktocat](https://github.com/guledfarah/PizzaProject/blob/master/2_OrderMade.PNG)

## Happy Coding!
